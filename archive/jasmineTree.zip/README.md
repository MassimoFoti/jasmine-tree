# jasmineTree
An add-on for Jasmine's HTML Reporter. With expand/collapse and cool CSS.

## Installation

Either:

- Simply download _jasmineTree.min.js_ from [here](https://raw.github.com/MassimoFoti/jasmineTree/master/dist/jasmineTree.min.js) and _jasmineTree.css_ from [here](https://raw.github.com/MassimoFoti/jasmineTree/master/dist/jasmineTree.css) then include them in your Jasmine's test runner file. Remember to also include jQuery

- Use Bower ```bower install jasmineTree```

jasmineTree is designed to work in IE9+ and most recent versions of Chrome and FireFox.

![Screenshot](https://raw.githubusercontent.com/MassimoFoti/jasmineTree/master/screenshot.jpg "Screenshot")
